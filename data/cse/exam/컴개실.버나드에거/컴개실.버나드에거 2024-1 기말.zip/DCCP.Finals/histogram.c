//------------------------------------------------------------------------------
// Digital Computer Concepts and Practice                           Spring 2024
//
//                                Final Examination
//
//
// Histogram
//
// Implement the function 'struct histo h classify(char *str)' that classifies
// the characters of a string into several categories.
// If str is NULL, the function returns a struct where all members are 0.
//
// The 'struct histo' contains the following members:
// struct histo {
//   int nonprintable;    // characters with ASCII code <= 31
//   int letter;          // characters 'A'...'Z', 'a'...'z'
//   int digit;           // characters '0'...'9'
//   int interpunct;      // characters ',', '.', '!', '?', ':'
//   int parenthesis;     // characters '(', ')', '{', '}', '[', ']'
//   int other;           // characters not part of any other class
// };
//
//
// Implement a second function 'void print(char *str, struct histo h)' that
// prints the string and the classification in a nicely formatted way:
//
//   String: <<str>>    (or "String: NULL" if str is NULL)
//   Histogram:
//     Non-printable:       0
//     Letters:            12
//     Digits:            111
//     Interpunctuation:    5
//     Parentheses:         6
//     Other:               1
//
// Make sure to use exactly the same amount of spaces and right-justify
// the numbers, otherwise domjudge will complain (you can use the output
// of domjudge to adjust your spacing).
//
// Usage:
// The program must be run with one arguments: the string to classify
//
//   $ make histogram
//   cc -Wall -g -o histogram histogram.c
//   $ ./histogram "How old are you? I am (let me think) 21!"
//   String: <<How old are you? I am (let me think) 21!>>
//   Histogram:
//     Non-printable:       0
//     Letters:            25
//     Digits:              2
//     Interpunctuation:    2
//     Parentheses:         2
//     Other:               9
//
// Debug:
// To debug in GDB, you can pass the arguments using GDB's '--args':
//
//   $ gdb --args ./histogram "Why, why, why....?!?"
//
// If you do not know how to use gdb, type "help" at the (gdb) prompt.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct histo {
  int nonprintable;    // characters with ASCII code <= 31
  int letter;          // characters 'A'...'Z', 'a'...'z'
  int digit;           // characters '0'...'9'
  int interpunct;      // characters ',', '.', '!', '?', ':'
  int parenthesis;     // characters '(', ')', '{', '}', '[', ']'
  int other;           // characters not part of any other class
};


int isin(const char* str, char val){
  for(int idx = 0;str[idx];idx++){ if(str[idx] == val){ return 1; } }
  return 0;
}

// struct histo classify(char *str)
//
struct histo classify(char *str)
{
  char c;
  struct histo res = (struct histo){ 0, 0, 0, 0, 0, 0 };
  if(!str){ return res; }

  for(int idx=0;str[idx];idx++){
    c = str[idx];
    if(c == '\"'){ continue; }
    if(c <= 31){ res.nonprintable++; continue; }
    if(('A'<=c && c<='Z') || ('a'<=c && c<='z')){ res.letter++; continue; }
    if('0'<=c && c<='9'){ res.digit++; continue; }
    if(isin(",.!?:", c)){ res.interpunct++; continue; }
    if(isin("(){}[]", c)){ res.parenthesis++; continue; }
    res.other++;
  }
  return res;
}

//   String: <<How old are you? I am (let me think) 21!>>
//   Histogram:
//     Non-printable:       0
//     Letters:            25
//     Digits:              2
//     Interpunctuation:    2
//     Parentheses:         2
//     Other:               9

// void print(char *str, struct histo h)
//
void print(char *str, struct histo h)
{
  if(!str){ printf("String: NULL\n"); }
  else{ printf("String: <<%s>>\n", str); }
  printf("Histogram:\n");
  printf("  Non-printable:   %5d\n", h.nonprintable);
  printf("  Letters:         %5d\n", h.letter);
  printf("  Digits:          %5d\n", h.digit);
  printf("  Interpunctuation:%5d\n", h.interpunct);
  printf("  Parentheses:     %5d\n", h.parenthesis);
  printf("  Other:           %5d\n", h.other);
  return;
}


//------------------------------------------------------------------------------
// DO NOT MODIFY PAST THIS POINT
//
int main(int argc, char *argv[])
{
  if (argc != 2) printf("Invalid usage. Expected exactly two arguments.\n");
  else {
    char *str = argv[1];

    // handle special cases
    if (!strcmp(str, "EMPTY")) str = "";
    else if (!strcmp(str, "NULL")) str = NULL;

    // call classify
    struct histo h = classify(str);

    // call print
    print(str, h);
  }

  return EXIT_SUCCESS;
}
