//------------------------------------------------------------------------------
// Digital Computer Concepts and Practice                           Spring 2024
//
//                                Final Examination
//
//
// Caesar Cipher
//
// Implement the function 'void encode(char *str, int rot, int swap)' that 
// encodes a string. If str is NULL, the function simply returns.
//
// The encoding algorithm operates as follows:
// 1. Each letter of the alphabet is rotated by 'rot' amount around the 
//    alphabet. ASCII characters that are not part of the alphabeth are left
//    as is. For example: 
//      rot == 1:  A->B, B->C, ..., Y->Z, Z->A, !->!, .->.
//      rot == 13: A->N, B->O, ..., M->Z, N->A, ..., Y->L, Z->M, !->!, .->.
//
//    Mathematically, if we represent A=0, B=1, C=2, ..., then we can express
//    the rotation as
//      R(x, r) = (x + r) mod 26
//    The same applies for lowercase letters.
//
//
// 2. If 'swap' is true, then the resulting character is converted from
//    uppercase to lowercase and vice-versa. For example: 
//      swap == 1: A->a, B->b, c->C, ...
//      swap == 0: A->A, b->b, c->c, ...
//
//    To convert from lowercase to uppercase and vice-versa, you can either 
//    use the C library functions 'toupper()' or 'tolower()' or remember that
//    the difference from an uppercase to its corresponding lowercase letter 
//    is exactly 0x20 and perform the calculation manually.
//
//
// Usage:
// The program must be run with three arguments: the string, the rot amount,
// and the swap flag.
//
//   $ make encode
//   cc -Wall -g -o encode encode.c
//   $ ./encode "Hello, there!" 10 1
//   <<rOVVY, DROBO!>>
//   $ ./encode "rOVVY, DROBO!" 16 1
//   <<Hello, there!>>
//
// Debug:
// To debug in GDB, you can pass the arguments using GDB's '--args':
//
//   $ gdb --args ./encode "Hello, there!" 10 1
//
// If you do not know how to use gdb, type "help" at the (gdb) prompt.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// void encode(char *str, int rot, int swap)
//
void encode(char *str, int rot, int swap)
{
  char c;
  int n;
  int mask = swap?0x20:0x00;
  for(int idx=0;str[idx];idx++){
    c = str[idx];
    if('A'<=c && c<='Z'){ str[idx] = (c-'A'+rot)%26+'A'^mask; continue; }
    if('a'<=c && c<='z'){ str[idx] = (c-'a'+rot)%26+'a'^mask; continue; }
  }
  return;
}



//------------------------------------------------------------------------------
// DO NOT MODIFY PAST THIS POINT
//
int main(int argc, char *argv[])
{
  if (argc != 4) printf("Invalid usage. Expected exactly three arguments.\n");
  else {
    char *str = argv[1];
    int rot = atoi(argv[2]);
    int swap = atoi(argv[3]);

    // handle special cases
    if (!strcmp(str, "EMPTY")) str = "";
    else if (!strcmp(str, "NULL")) str = NULL;

    // call encode
    encode(str, rot, swap);

    // print result
    if (str != NULL) printf("<<%s>>\n", str);
    else printf("NULL\n");
  }

  return EXIT_SUCCESS;
}
