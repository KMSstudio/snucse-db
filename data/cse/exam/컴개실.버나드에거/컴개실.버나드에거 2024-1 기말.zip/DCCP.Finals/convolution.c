//------------------------------------------------------------------------------
// Digital Computer Concepts and Practice                           Spring 2024
//
//                                Final Examination
//
//
// Convolution
//
// Implement the function 
//   'void conv(float *out[OY][OX], float *in[IY][IX], float *kernel[K][K])'
// that calculates a convolution.
//
// The convolution operation applies the convolution kernel to the input matrix
// and generates an output matrix.
//
// An output pixel out[y][x] is the sum of the results obtained by element-wise
// multiplication of the input from [y][x]...[y+K-1][x+K-1] with the kernel
// for each element in the output.
//
// You can assume that the input is always K-1 elements wider in both 
// dimensions, so you do not have to check that the dimensions match. 
// In other words, OX = IX + K-1 and OY = IY + K-1.
//
// Usage:
// The program must be run with one arguments, a random seed that is used
// to initialize the matrices.
//
//   $ make convolution
//   cc -Wall -g -o convolution convolution.c
//   $ ./convolution 0
//
// Debug:
// To debug in GDB, you can pass the arguments using GDB's '--args':
//
//   $ gdb --args ./convolution 0
//
// If you do not know how to use gdb, type "help" at the (gdb) prompt.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// matrix dimensions
#define K 3
#define OX 7
#define OY 5
#define IX (OX+K-1)
#define IY (OY+K-1)



// void conv(float out[OY][OX], float in[IY][IX], float kernel[K][K])
//
void conv(float out[OY][OX], float in[IY][IX], float kernel[K][K])
{
  for(int row=0;row<OY;row++){
    for(int col=0;col<OX;col++){
      out[row][col] = 0;
      for(int y=0;y<K;y++){
        for(int x=0;x<K;x++){
          out[row][col] += in[row+y][col+x] * kernel[y][x]; }
      }

    }
  }
  return;
}



//------------------------------------------------------------------------------
// DO NOT MODIFY PAST THIS POINT
//

void init(float *m, int Y, int X)
{
  for (int y=0; y<Y; y++)
    for (int x=0; x<X; x++)
      *(m + y*X + x) = (float)rand() / RAND_MAX;
}

void print(char *name, float *m, int Y, int X)
{
  printf("  %s = [\n", name);
  for (int y=0; y<Y; y++) {
    printf("  ");
    for (int x=0; x<X; x++) printf("  %.3f", *(m + y*X + x));
    printf("\n");
  }
  printf("  ]\n");
}

int main(int argc, char *argv[])
{
  if (argc != 2) printf("Invalid usage. Expected exactly one argument.\n");
  else {
    int seed = atoi(argv[1]);
    srand(seed);

    float o[OY][OX];
    float i[IY][IX];
    float k[K][K];

    // initialize matrices
    init((float*)i, IY, IX);
    init((float*)k, K, K);
    memset((float*)o, 0, sizeof(float)*OY*OX);

    // print status before convolution
    printf("Convolving");
    print("in", (float*)i, IY, IX);
    print("kernel", (float*)k, K, K);
    printf("\n");

    // call conv
    conv(o, i, k);

    // print result
    print("out", (float*)o, OY, OX);
  }

  return EXIT_SUCCESS;
}
