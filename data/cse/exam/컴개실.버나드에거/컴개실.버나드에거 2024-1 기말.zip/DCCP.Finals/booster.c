//------------------------------------------------------------------------------
// Digital Computer Concepts and Practice                           Spring 2024
//
//                                Final Examination
//
//
// Confidence Booster
//
// Implement the function 'void boost(char *fmtstr, int amount)' that uses
// printf() to output a formatted string to the terminal, followed by a
// newline.
// If str is NULL, the function simply returns.
//
// The argument 'fmtstr' itself may contain a format specifier to encode
// the second argument 'amount'.
//
//
// Usage:
// The program must be run with two arguments: the string, and the amount.
//
//   $ make booster
//   cc -Wall -g -o booster booster.c
//   $ ./booster "Hello, there!" 0
//   <<Hello, there!>>
//   $ ./booster "Confidence boosted to %d percent!" 100
//   <<Confidence boosted to 100% percent!>>
//
// Debug:
// To debug in GDB, you can pass the arguments using GDB's '--args':
//
//   $ gdb --args ./booster "Why, why, why....%d" 10
//
// If you do not know how to use gdb, type "help" at the (gdb) prompt.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// void boost(char *fmtstr, int amount)
//
void boost(char *fmtstr, int amount)
{
  if(!fmtstr){ return; }
  printf(fmtstr, amount);
  return;
}



//------------------------------------------------------------------------------
// DO NOT MODIFY PAST THIS POINT
//
int main(int argc, char *argv[])
{
  if (argc != 3) printf("Invalid usage. Expected exactly two arguments.\n");
  else {
    char *str = argv[1];
    int amount = atoi(argv[2]);

    // handle special cases
    if (!strcmp(str, "EMPTY")) str = "";
    else if (!strcmp(str, "NULL")) str = NULL;

    // call boost
    boost(str, amount);
  }

  return EXIT_SUCCESS;
}
