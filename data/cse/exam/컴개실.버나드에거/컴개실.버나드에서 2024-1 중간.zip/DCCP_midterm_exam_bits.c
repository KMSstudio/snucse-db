//------------------------------------------------------------------------------
// Digital Computer Concepts and Practice          Practical Midterm Examination
//
// Bit manipulations
//


// Instructions
// ------------
// Implement the requested functionality with the operators specified in the
// function description.
//
// Your implementation is tested for correctness and performance.
// - Correctness points are awarded if the solution is correct.
// - Performance points are awarded if you use up to 'Max ops' operators.
//
// When coding your solution, you are allowed to
// - use the operators that are listed in the function specification
// - directly encode constants from 0 to 255 (0x00 to 0xff)
//
// This means that you are not allowed to call any functions, use loops, use
// operators other than the allowed ones, or constants outside the allowed 
// range.
//
//
// Example:
//   /*
//    * isZero - returns 1 if x == 0, and 0 otherwise
//    *   Examples: isZero(5) = 0, isZero(0) = 1
//    *   Legal ops: ! ~ & ^ | + << >>
//    *   Max ops: 2
//    *   Rating: 1
//    */
//   int isZero(int x) {
//     return 2;
//   }
//
//   You are allowed to use !, ~, &, ^, |, |, <<, and >> to implement the
//   'isZero' functionality.
//
//   One possible solution could be:
//
//   /*
//    * isZero - returns 1 if x == 0, and 0 otherwise
//    *   Examples: isZero(5) = 0, isZero(0) = 1
//    *   Legal ops: ! ~ & ^ | + << >>
//    *   Max ops: 2
//    *   Rating: 1
//    */
//   int isZero(int x) {
//     return !!x;
//   }
//


/*
 * minusTwo - return -2
 *   Legal ops: ! ~ & | ^ +
 *   Max ops: 2
 *   Points: 5
 */
int minusTwo(void)
{
  return ~1;
}
/*
 * bitComplement - return ~x without using ~.
 *   Example: bitComplement(0x8acf1460) = 0x7530eb9f
 *   Legal ops: ! & | ^ << >> +
 *   Max ops: 8
 *   Points: 10
 */
int bitComplement(int x)
{
  int y = 0xFF;
  y = y | y<<8;
  y = y | y<<16;
  return y^x;
}
/*
 * countZeros - returns the number of 0's in word
 *   Examples: countZeros(1) = 31, countZeros(-1) = 0, countZeros(0x55555555) = 16
 *   Legal ops: ! ~ & | ^ << >> +
 *   Max ops: 40
 *   Points: 10
 */
int countZeros(int x)
{
  int mask = 0x11;
  int sum=0, val=0;
  mask = mask << 8 | mask; //0x1111
  mask = mask << 16 | mask; //0x11111111 use 4 operator
  x=~x; //lets's count 1 x have
  sum = (x&mask) + (x>>1&mask) + (x>>2&mask) + (x>>3&mask); // 12op
  sum = sum + (sum>>4);
  val = (sum&0xF) + (sum>>8&0xF) + (sum>>16&0xF) + (sum>>24&0xF);
  return val;
}
